part of 'appbar_bloc.dart';

 class AppbarState extends Equatable {
  final double elevation;
  const AppbarState({this.elevation});

  @override
  List<Object> get props => [elevation];
}
