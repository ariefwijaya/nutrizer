const String baseHttp = "http://";
const String baseHost = "150.242.111.19";
const String baseUrl = "/testapi/api/";
const String apiKey = "01c5d0d1ff15325934327ab3965e26f6";
const String appName = "NUTRIZER";
const String appTagLine = "PREGNANCY NUTRITION ANALYZER";
const String appDescription =
    "Memberikan informasi tentang gizi dan membantu mencegah kekurangan energi kronis pada masa kehamilan.";
    const String androidAppId = "com.etramatech.nutrizer";
    const String iosAppId = "";
    const String androidStoreUrl = "https://play.google.com/store/apps/details?id=com.etramatech.nutrizer";
    const String iosStoreUrl = "";
