class AssetsHelper {
  static final String assetImagePath = "assets/images/";
  static final String assetIconPath = "assets/icons/";
  static String assetPathAppLogo = "${assetIconPath}nutrizer_logo.png";
  static String assetPathPerson = "${assetIconPath}woman_stand.png";
  static String onBoardingFront = "${assetImagePath}onboarding_front.png";
  static String seaweedSmall = "${assetIconPath}seaweed_small.png";
  static String leavesDecor1 = "${assetImagePath}leaves_decor_1.png";
  static String leavesDecor2 = "${assetImagePath}leaves_decor_2.png";
  static String arrow = "${assetIconPath}arrow.png";
  static String person = "${assetIconPath}person.png";
  static String weightIcon = "${assetIconPath}weight_icon.png";
  static String heightIcon = "${assetIconPath}height_icon.png";
  static String invite = "${assetImagePath}invite.png";
  static String error = "${assetImagePath}error.png";
  static String notfound = "${assetImagePath}notfound.png";
  static String offline = "${assetImagePath}offline.png";
  static String confirmation = "${assetImagePath}confirmation.png";
  static String aboutApp = "${assetImagePath}aboutapp.png";
  static String seaweedBanner = "${assetImagePath}seaweed_banner.png";
  static String book = "${assetImagePath}book.png";
  static String calculator = "${assetImagePath}calculator.png";
  static String sleep = "${assetImagePath}sleep.png";
  static String nutrition = "${assetIconPath}nutrition.png";
}
